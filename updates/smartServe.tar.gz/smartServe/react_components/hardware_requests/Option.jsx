import React from 'react';

export default class Options extends React.Component {
  constructor(){
    super();
  }
  render(){
    return(
      <option className={this.props.className} value={this.props.value}>{this.props.option}</option>
    )
  }
}
