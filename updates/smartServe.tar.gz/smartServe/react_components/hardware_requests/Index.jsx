import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import { Router, Route, Link, IndexRoute, hashHistory, browserHistory } from 'react-router'

// import App from './App.jsx'
import Content from './Content.jsx'
import OrderSummary from './OrderSummary.jsx'
import SvdCheck from './SvdCheck.jsx'

class Rout extends Component{
	render(){
		return(
			<Router history={ browserHistory }>
				<Route path='/hardwarerequest' component={Content} />
				<Route path='/hardwarerequest/svdcheck' component={SvdCheck} />
				<Route path='/hardwarerequest/order' component={TwitterFeed} />
			</Router>
		)
	}
}

ReactDOM.render(<Index />, document.getElementById('entry-points'))
