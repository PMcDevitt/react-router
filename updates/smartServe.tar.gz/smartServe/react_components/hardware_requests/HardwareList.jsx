import React from 'react';
import object from '../../const/hardware_object';
import HardwareItem from './HardwareItem.jsx';
// import fs from 'fs';

export default class HardwareList extends React.Component {
  constructor(){
    super();
    this.state = {
      items: object
    }
  }
  render(){
    var that = this;
    var items = this.state.items.filter(function(item, index, array){
      if(that.props.justification==='oncall'){
        return item.type === 'Laptop';
      }else if(that.props.justification==='lab'){
        return item.type === 'Lab';
      }else{
        if(that.props.filterHardware === 'all'){
          if(that.props.location === 'India'){
            return item.type !== 'Thin Client'
          }
          return item;
        }else if(that.props.filterHardware === 'laptop'){
          return item.type === 'Laptop';
        }else if(that.props.filterHardware === 'desktop'){
          return item.type === 'Desktop'
        }else if (that.props.filterHardware === 'apple') {
          return item.type === 'Apple'
        }else if (that.props.filterHardware === 'tablet') {
          return item.type === 'Tablet'
        }else if (that.props.filterHardware === 'thinclient') {
          return item.type === 'Thin Client'
        }else{
          return item;
        }
      }
    })
    .map(function(item, index, array){
        return (
          <HardwareItem key={item.id} name={item.name} id={item.id} imageURL={item.imageURL} desc={item.shortDesc} type={item.type} price={item.price} location={that.props.location} justification={that.props.justification}/>
        )
      });
    return (
      <div className='row'>
        {items}
      </div>
    )
  }
}
