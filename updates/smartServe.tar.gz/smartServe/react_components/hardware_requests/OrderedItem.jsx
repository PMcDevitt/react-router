'use strict'
import React from 'react';

export default class OrderedItem extends React.Component {
  constructor(){
    super();
  }

  render(){
    return (
      <div className='col-md-6 ordered-item' data-name={this.props.name} data-id={this.props.id} data-quantity={this.props.qunatity}>
        <div className='row'>
          <div className='col-md-12'>
            <div className='panel panel-primary'>
              <div className='panel-heading'>
                <div className='row'>
                  <div className='col-sm-8'>
                    <h3>{this.props.name}</h3>
                  </div>
                  <div className='col-sm-4'>
                    <small>Quantity: {this.props.quantity}</small>
                  </div>
                </div>
              </div>
              <div className='panel-body'>
                <ul>
                  <li>Thunderbolt to VGA adapter</li>
                  <li>Thunderbolt to ethernet adapter</li>
                  <li>MacLock</li>
                  <li>Security Lock</li>
                  <li>Laptop bag</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
