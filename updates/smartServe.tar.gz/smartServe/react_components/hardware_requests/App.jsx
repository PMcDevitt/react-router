import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import { Router, Route, Link, IndexRoute, hashHistory, browserHistory } from 'react-router'

import Content from './Content.jsx'
import OrderSummary from './OrderSummary.jsx'
import SvdCheck from './SvdCheck.jsx'

var DefaultRoute = Router.DefaultRoute;
// var Route = Router.Route;

class App extends Component{
	render(){
		return(
			<Router history={ browserHistory }>
				<Route path='hardwarerequest' component={Container} >
					<IndexRoute component={Content} />
					<Route name='svdcheck' path='svdcheck' component={SvdCheck} />
					<Route name='ordersummary' path='ordersummary' component={OrderSummary} />
					<Route name='address' path='address' handler={Address} />
  			 	<Route name='*' path='*' handler={NotFound} />
				</Route>
			</Router>
		)
	}
}

const Nav = () => (
  <div>
    <Link to='/hardwarerequest'>Home</Link>&nbsp;
    <Link to='/hardwarerequest/address'>Address</Link>
  </div>
)

const Container = (props) => (<div>
  <Nav />
  {props.children}
</div>)

const Home = () => <h1>Hello from Home!</h1>
const Address = () => <h1>We are located at 555 Jackson St.</h1>
const NotFound = () => <h1>404.. This page is not found!</h1>


// Router.run(routes, function (Handler, state) {
//   React.render(<Handler />, document.getElementById('entry-point'));
// });
ReactDOM.render(<App />, document.getElementById('entry-point'))
