'use strict'
import React from 'react';

export default class HardwareItem extends React.Component {
  constructor(){
    super();
  }
  changeToPlaceholder(e){
    e.target.src = '/images/placeholder.gif'
  }
  selectItem(e){
    e.target.value > 0 ? $(e.target).closest('.hardwareItem').addClass('hardwareItemHighlight') : $(e.target).closest('.hardwareItem').removeClass('hardwareItemHighlight')
  }
  render(){
    var that = this;
    return (
      <div className='col-md-3 hardwareItem' data-type={this.props.type} data-price={this.props.price} data-name={this.props.name} data-id={this.props.id}>
        <hr />
        <h3 className='hdg'>{this.props.name}</h3>
        <hr />
        <img onError={this.changeToPlaceholder} alt={this.props.name} src={this.props.imageURL} className='img-responsive hardware-item'/>
        <div className='row'>
          <div className='col-md-12 hardware-item'>
            {this.props.desc}
          </div>
        </div>
        <div className='row'>
          <div className='col-md-4'>
            <label><u>Quantity:  </u></label>
          </div>
          <div className='col-md-4'>
            {this.props.justification==='all' &&
              <input type='number' ref='quantity' disabled='true' className='form-control input-sm hardware-quantity-field' max='999' min='0' defaultValue='0' onChange={this.selectItem.bind(this)}/>
            }
            {this.props.justification!=='all' &&
              <input type='number' ref='quantity' className='form-control input-sm hardware-quantity-field' max='999' min='0' defaultValue='0' onChange={this.selectItem.bind(this)}/>
            }
          </div>
        </div>
        {this.props.location==='United States' &&
        <div className='row'>
          <div className='col-md-6'>
            <label className='hardware-price'><strong>${this.props.price}</strong></label>
          </div>
        </div>
        }
        <br/>
      </div>
    )
  }
}
