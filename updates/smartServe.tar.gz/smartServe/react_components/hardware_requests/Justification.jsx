import React from 'react';

export default class Justification extends React.Component {
  constructor(){
    super();
  }
  handleChange(e){
    // console.log(e.target.value);
    this.props.handleJustificationChange(e.target.value)
  }
  render(){
    if(this.props.location === 'United States'){
      return (
        <div className='row'>
          <div className='col-md-12'>
            <label for='justification'>Why do you need this device?</label>
            <select className='form-control' id='justification' defaultValue='na' onChange={this.handleChange.bind(this)}>
              <option className='justificationClass' value='na' disabled>-- Select An Option --</option>
              <option className='justificationClass' value='newemp'>New employee</option>
              <option className='justificationClass' value='behalf'>Requesting on behalf of someone else</option>
              <option className='justificationClass' value='oncall'>Team support / on-call laptop</option>
              <option className='justificationClass' value='lab'>Requesting lab machine</option>
              <option className='justificationClass' value='migrate'>Migrate to new device</option>
              <option className='justificationClass' value='broken'>Replace broken and out of warranty equipment</option>
            </select>
          </div>
        </div>
      )
    }else{
      return (
        <div className='row'>
          <div className='col-md-12'>
            <label for='justification'>Why do you need this device?</label>
            <select className='form-control' id='justification' defaultValue='na' onChange={this.handleChange.bind(this)}>
              <option className='justificationClass' value='na' disabled>-- Select An Option --</option>
              <option className='justificationClass' value='newemp'>New employee</option>
              <option className='justificationClass' value='behalf'>Requesting on behalf of someone else</option>
              <option className='justificationClass' value='oncall'>Team support / on-call laptop</option>
              <option className='justificationClass' value='lab'>Requesting lab machine</option>
              <option className='justificationClass' value='migrate'>Migrate to new device</option>
            </select>
          </div>
        </div>
      )
    }
  }
}
