# smartServe
smartServe project. A new user friendly service catalog
