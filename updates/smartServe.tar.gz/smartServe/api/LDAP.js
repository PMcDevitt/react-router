'use strict'

var LDAPAPI = function(){
  var ldap = require('ldapjs');
  this.client = ldap.createClient({
    url: 'LDAP://gldc-ad-gc-vip.igslb.allstate.com:3268'
  });
};

LDAPAPI.prototype.authenticate = function(NTID){
  var opts = {
    filter: '(&(objectClass=user)(samaccountname=' + NTID + '))',
    scope: 'sub'
  };
  var that = this;
  var promise = new Promise(function(resolve, reject){
    that.client.bind('sys-cf-smrt', 'Cp93AMoe', function(err){
      if(err){
        console.log(err);
        return reject(false);
      }
      that.client.search('DC=ad,DC=allstate,DC=com', opts, function(err, res){
        if(err){
          return reject(false);
        }
        res.on('searchEntry', function(entry){
          return resolve(true);
        })
        res.on('end', function(error){
          return reject(false);
        })
      })
    })
  })
  return promise;
};

LDAPAPI.prototype.getInfo = function(NTID){
  var opts = {
    filter: '(&(objectClass=user)(samaccountname=' + NTID + '))',
    scope: 'sub'
  };
  var that = this;
  return new Promise(function(resolve, reject){
    that.client.bind('sys-cf-smrt', 'Cp93AMoe', function(err){
      if(err){
        reject(err);
      }
      that.client.search('DC=ad,DC=allstate,DC=com', opts, function(err, res){
        if(err){
          reject(err);
        }
        res.on('searchEntry', function(entry){
          return resolve(entry.object);
        })
        res.on('end', function(error){
          return reject();
        })
      })
    })
  })
};

module.exports = LDAPAPI;
