$(document).ready(function(){
  if(localStorage.getItem('info')== null){
    $('#getinfocontainer').hide();
    $('.masthead-user').text('Welcome Paddy ');
  }
  // $('#getinfo').click(function(){
  //   var url = '/users/' + $('#ntid').val() + '/getinfo';
  //   console.log(url);
  //   $.ajax(url)
  //     .done(function(userinfo){
  //       console.log('success');
  //       console.log(userinfo);
  //       console.log(ntid);
  //       localStorage.setItem('info', JSON.stringify(userinfo));
  //       $('#getinfocontainer').hide();
  //       var info = JSON.parse(localStorage.getItem('info'));
  //       console.log('info', info);
  //       $('.masthead-user').text('Welcome ' + info.givenName + ' ' + info.sn);
  //     })
  // })
})
