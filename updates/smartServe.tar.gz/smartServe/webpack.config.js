var webpack = require('webpack');

module.exports = {
  entry: {
    hardwarerequest:  __dirname + '/react_components/hardware_requests/App.jsx'
  },
  module: {
    loaders: [
      {
        test: /\.jsx?$/,
        exclude: /(node_modules)/,
        loader: 'babel-loader',
        query: {
          presets: ['react', 'es2015', 'stage-0'],
          plugins: ['react-html-attrs', 'transform-class-properties', 'transform-decorators-legacy']
        }
      }
    ]
  },
  output: {
    path: __dirname + '/public/javascripts',
    filename: 'react.min.js'
  }
}
