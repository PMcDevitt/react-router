var express = require('express');
var router = express.Router();
var LDAP = require('../api/LDAP');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/:ntid/getinfo', function(req, res, next){
  var auth = new LDAP();
  auth.getInfo(req.params.ntid).then(
    (info)=>{
      res.json(info)
    },
    ()=>{
        res.status(401).end();
    }
  )
})

module.exports = router;
