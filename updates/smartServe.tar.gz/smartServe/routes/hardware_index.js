'use strict'
var express = require('express');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('hardwarerequest/hardware_index');
});

// router.post('/continue', function(req, res, next){
//
//   var order = JSON.parse(req.body.order);
//
//   ///////var groups = JSON.parse(req.body.memberOf)
//   var items = order.items
//
//   var page_url = '/hardwarerequest/order';
//     console.log(33, '/continue');
//   for(var i=0; i < items.length; i++){
//     if (items[i].type==='Thin Client') {
//       page_url = '/hardwarerequest/svdcheck'
//       for(var j=0; j<groups.length; j++){
//         if((groups[j].indexOf('CCVO_BA') > -1) || (groups[j].indexOf('DVD') > -1)){
//           page_url = '/hardwarerequest/ordersummary';
//         }
//       }
//     }
//   }
//   res.send(page_url);
// })

router.get('/svdcheck', function(req, res, next){
    console.log(3333, '/svdcheck');
  res.render('hardwarerequest/hardware_index');
})

router.get('/ordersummary', (req, res, next)=>{
  console.log(3333, '/ordersummary');
  res.render('hardwarerequest/hardware_index');
})

module.exports = router;
