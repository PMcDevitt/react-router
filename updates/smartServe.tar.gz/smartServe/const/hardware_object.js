'use strict'
const object = [
  {
    id: 1,
    name: 'Macbook Pro 15"',
    type: 'Apple',
    Desc: 'Apple Macbook Air 15.4-inch (2880 x 1800), 5th Generation Intel(R) Core(TM) i7 Dual Core Processor (up to 2.2 GHz), 16GB LPDDR3 1866Mhz, 256GB PCIe Solid State Drive, Wireless-AC 802.11ac/a/b/g/n 2x2, Intel® HD Graphics Iris Pro, Ports: (2) Thunderbolt , (2) USB 3.0, (1) HDMI, (1) DisplayPort to VGA Adapter, Expansion: (1) SD 4.0 Memory card reader, Integrated sound with combo microphone and headphone jack, 720p HD Webcam, Backlit Keyboard, USB to Ethernet Adapter, 99.5WHr Integrated Battery, 85 Watt MagSafe 2 AC Adapter',
    shortDesc: '15 inch Mcabook Pro with Intel i7 processor, 16GB RAM, 256GB SSD, includes USB to Ethernet adpater and VGA Adapter',
    imageURL: '/images/hardware/1.jpg',
    price: 2205.00
  },
  {
    id: 2,
    name: 'Macbook Pro 13"',
    type: 'Apple',
    Desc: 'Apple Macbook Pro 13.3-inch (2560 x 1600), 5th Generation Intel(R) Core(TM) i5 Dual Core Processor (up to 2.7 GHz), 8GB LPDDR3 1866Mhz, 256GB PCIe Solid State Drive, Wireless-AC 802.11ac/a/b/g/n 2x2, Intel® HD Graphics 6100, Ports: (2) Thunderbolt , (2) USB 3.0, (1) DisplayPort to VGA Adapter, Expansion: (1) SD 4.0 Memory card reader, Integrated sound with combo microphone and headphone jack, 720p HD Webcam, Backlit Keyboard, USB to Ethernet Adapter, 74.9WHr Integrated Battery, 60 Watt MagSafe 2 AC Adapter',
    shortDesc: '13 inch Mcabook Pro with Intel i5 processor, 8GB RAM, 256GB SSD, includes USB to Ethernet adpater and VGA Adapter',
    imageURL: '/images/hardware/1.jpg',
    price: 1704.00
  },
  {
    id: 3,
    name: 'Macbook Air',
    type: 'Apple',
    Desc: 'Apple Macbook Air 13.3-inch (1440 x 900), 5th Generation Intel(R) Core(TM) i5 Dual Core Processor (up to 2.7 GHz), 8GB LPDDR3 1866Mhz, 128GB PCIe Solid State Drive, Wireless-AC 802.11ac/a/b/g/n 2x2, Intel® HD 6000, Ports: (2) Thunderbolt , (2) USB 3.0, (1) DisplayPort to VGA Adapter, Expansion: (1) SD 4.0 Memory card reader, Integrated sound with combo microphone and headphone jack, 720p HD Webcam, Backlit Keyboard, USB to Ethernet Adapter, 54WHr Integrated Battery, 45 Watt MagSafe 2 AC Adapter',
    shortDesc: '13 inch Mcabook Air with Intel i5 processor, 8GB RAM, 128GB SSD, includes USB to Ethernet adpater and VGA Adapter',
    imageURL: '/images/hardware/2.jpg',
    price: 1321.00
  },
  {
    id: 4,
    name: 'Standalone iMac',
    type: 'Apple',
    Desc: '27-inch (5120 x 2880) bundled includes 27” Apple Thunderbolt Display (2560 x 1440), 5th Generation Intel(R) Core(TM) i7 Quad Core Processor (up to 4.0 GHz), 16GB LPDDR3 1866Mhz, 256GB PCIe Solid State Drive, Wireless-AC 802.11ac/a/b/g/n 2x2, AMD Radeon R9 M395, Ports: (2) Thunderbolt , (4) USB 3.0, Expansion: (1) SD 4.0 Memory card reader, Integrated sound with combo microphone and headphone jack, 720p HD Webcam, Apple Keyboard with Numeric Keypad and Microsoft Comfort Mouse 4500 bundle includes 2',
    shortDesc: '27 inch iMac with Intel i7 processor, 16GB RAM, 256GB SSD, includes keyboard and mouse',
    imageURL: '/images/hardware/3.jpg',
    price: 2857.00
  },
  {
    id: 5,
    name: 'Compozed iMac',
    type: 'Apple',
    Desc: '27-inch (5120 x 2880) bundled includes 27” Apple Thunderbolt Display (2560 x 1440), 5th Generation Intel(R) Core(TM) i7 Quad Core Processor (up to 4.0 GHz), 16GB LPDDR3 1866Mhz, 256GB PCIe Solid State Drive, Wireless-AC 802.11ac/a/b/g/n 2x2, AMD Radeon R9 M395, Ports: (2) Thunderbolt , (4) USB 3.0, Expansion: (1) SD 4.0 Memory card reader, Integrated sound with combo microphone and headphone jack, 720p HD Webcam, Apple Keyboard with Numeric Keypad and Microsoft Comfort Mouse 4500 bundle includes 2',
    shortDesc: '27 inch iMac with Intel i7 processor, 16GB RAM, 256GB SSD, includes keyboard and mouse',
    imageURL: '/images/hardware/3.jpg',
    price: 3675.00
  },
  {
    id: 6,
    name: 'Standard Desktop',
    type: 'Desktop',
    Desc: 'Micro Chassis, Intel® CoreTM i3-6100T (3.2GHz, 3MB cache, 2 cores, 4 threads), 8GB DDR3L-1600 MHz, 128GB 2.5 inch Serial ATA Solid State, No Optical Drive, Integrated Intel® HD Graphics 530, Front Ports: (2) USB 3.0, (1) headphone/microphone jack, (1) microphone jack, Rear Ports: (4) USB 3.0, (1) DisplayPort, (1)HDMI, (1) RJ45, (1) DVI-D to HDMI Adapter',
    shortDesc: 'Standard desktop with Intel i3 processor, 8GB RAM, 128GB Harddrive, Integrated Intel HD Graphics.',
    imageURL: '/images/hardware/4.jpg',
    price: 368.52
  },
  {
    id: 7,
    name: 'Developer Desktop',
    type: 'Desktop',
    Desc: 'Small form facotr chasis, Intel® CoreTM i7-6700 (3.4GHz, 8MB Cache, 4 cores, 8 threads) 16GB (2x8GB) 1600MHz DDR3, 3.5 inch 500GB 7200rpm HDD, No Optical Drive, Integrated Intel® HD Graphics 530, Front Ports: (2) USB 3.0, (2) USB 2.0 (1) headphone jack, (1) microphone jack, Rear Ports: (4) USB 3.0, (2) USB 2.0 (1) RJ-45; (1) Serial; (1) HDMI; (2) DisplayPort; (2) PS/2 (1) headphone jack, (1) microphone jack',
    shortDesc: 'Developer desktop with Intel i7 processor, 16GB RAM, 500GB HDD, Integrated Intel HD Graphics',
    imageURL: '/images/hardware/5.png',
    price: 716.67
  },
  {
    id: 8,
    name: 'Lab Desktop',
    type: 'Lab',
    Desc: '',
    shortDesc: 'Lab Desktop for doing lab desktop stuff, this will be used for most lab technicians',
    imageURL: '/images/hardware/6.jpg',
    price: 849.99
  },
  {
    id: 9,
    name: 'Thin Client',
    type: 'Thin Client',
    Desc: 'AMD G Series 1.4 GHz, 4 GB DDR3, 8GB or 16GB Flash Storage, AMD Radeon HD 6250 Graphics, Windows Embedded 7 OS, Dual-Band WLAN 802.11 a/b/g/n, Gigabit Ethernet, Front Ports: 2 USB 2.0, (1) headphone/microphone jack, Rear Ports: (1) Displayport (w/ VGA adapter), (1) DVI-I, (2) USB 2.0',
    shortDesc: 'Thin client, AMD G Series, 4GB RAM, 8GB/16GB Flash storage, AMD Radeon HD 6250 Graphics with 1GB Ethernet. Requires SVD/DVD access',
    imageURL: '/images/hardware/7.jpg',
    price: 345.18
  },
  {
    id: 10,
    name: 'Standard Laptop',
    type: 'Laptop',
    Desc: '14" diagonal LED-backlit HD anti-glare (1366 x 768 ), 6th Generation Intel® CoreTM i5-6300U (2.4GHz, 3M cache, Dual Core, 4 threads), 8GB (1x8GB) 2133MHz DDR4 Memor, 128GB 2.5 inch Serial ATA Solid State Drive, Latitude, Intel® Dual Band Wireless-AC 8260AC 802.11ac/a/b/g/n 2x2, Intel® Integrated HD Graphics 520, No Optical Drive, Ports: (1) VGA, (1) HDMI, (3) USB 3.0, (1) RJ45, (1) SD 4.0 Memory card reader • Integrated stereo speaker, integrated microphone, 720p HD Webcam, Integrated Intel® I219 LAN',
    shortDesc: 'Standard 14 inch Laptop with Intel i5 processor, 8GB RAM, 128GB SSD, Integrated HD Graphics 520',
    imageURL: '/images/hardware/8.jpg',
    price: 613.14
  },
  {
    id: 11,
    name: 'Developer Laptop',
    type: 'Laptop',
    Desc: '15.6inch UltraSharp FHD(1920x1080) Wide View Anti-Glare LED-backlit • Intel CoreTM i7-6820HQ Processor (Quad Core 2.7GHz, 8MB cache), 16GB 2133MHz DDR4 (2x8GB), 256GB Mobility Solid State Drive, Intel® Dual Band Wireless-AC 8260 802.11ac/a/b/g/n 2x2 + Bluetooth 4.0 LE Half Mini Card, AMD R7 M370 with 2GB GDDR5 memory & Intel HD 520, No Optical Drive, Ports: (1) USB C, (1) VGA, (1) HDMI, (3) USB 3.0, (1) Stereo global headset jack, (1) RJ45, (1) Memory card reader, Integrated stereo speaker, integrated microphone, 720p HD Webcam',
    shortDesc: '15.6 inch Developer laptop with Intel i7 processor, 16GB RAM, 256GB SSD, AMD R7 M370 2GB & Intel HD 520',
    imageURL: '/images/hardware/9.jpg',
    price: 1183.57
  },
  {
    id: 12,
    name: 'Galaxy TabPro 16GB',
    type: 'Tablet',
    Desc: '10.1-inch Display (2560 x 1600), Octa Core Exynos 1.9 GHz Processor, 2GB RAM, 16GB Storage, Dual Band Wireless AC, Ports: (1) Micro USB , (1) 3.5mm Headphone jack, MicroSD Card Slot max capacity 64 GB, Camera: 8 Megapixel rear facing, 2 Megapixel front-facing, 8220 mAh Integrated Battery, Dimension: 9.6” x 6.7” x .3”, Starting weight: 1.03 lbs, AC Adapter, Smart Cover 2 Black, 2 year Pro Warranty',
    shortDesc: 'Galaxy TabPro with 1.9GHz processor, 2GB RAM, 16GB Storage, Front and Rear facing cameras, includes 2 years warranty.',
    imageURL: '/images/hardware/10.jpg',
    price: 555.00
  },
  {
    id: 13,
    name: 'Galaxy TabPro 32GB',
    type: 'Tablet',
    Desc: '10.1-inch Display (2560 x 1600), Octa Core Exynos 1.9 GHz Processor, 2GB RAM, 32GB Storage, Dual Band Wireless AC, Ports: (1) Micro USB , (1) 3.5mm Headphone jack, MicroSD Card Slot max capacity 64 GB, Camera: 8 Megapixel rear facing, 2 Megapixel front-facing, 8220 mAh Integrated Battery, Dimension: 9.6” x 6.7” x .3”, Starting weight: 1.03 lbs, AC Adapter, Smart Cover 2 Black, 2 year Pro Warranty',
    shortDesc: 'Galaxy TabPro with 1.9GHz processor, 2GB RAM, 32GB Storage, Front and Rear facing cameras, includes 2 years warranty.',
    imageURL: '/images/hardware/10.jpg',
    price: 618.00
  }
];

module.exports = object;
// export hardwareList;
