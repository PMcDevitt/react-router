require('../helper')

describe('given LDAP class', function(){
  var LDAPAPI = require('../../api/LDAP');
  describe('when calling authenticate with valid credentials', function(){
    it('should return true', function(done){
      var auth = new LDAPAPI();
      auth.authenticate('sys-cf-smrt').then(
        function (result){
          expect(result).to.eql(true);
        }
      ).then(done, done);
    })
  })

  describe('when calling authenticate with invalid credentials', function(){
    it('should return false', function(done){
      var auth = new LDAPAPI();
      auth.authenticate('sys-cf-sm').then(
        function(result){
          expect(result).to.eql(false);
        }
      ).then(done, done);
    })
  })

  describe('when calling getInfo with valid credentials', function(){
    it('should return object with users information', function(done){
      var auth = new LDAPAPI();
      auth.getInfo('sys-cf-smrt').then(
        function(result){
          expect(result).to.be.instanceOf(Object);
          expect(result.sAMAccountName).to.eql('sys-cf-smrt');
        }
      ).then(done, done)
    })
  })

  describe('when calling getInfo with invalid credentials', function(){
    it('should return true', function(done){
      var auth = new LDAPAPI();
      auth.getInfo('sys-cf-sm').then(
        function(result){
          expect(result).to.be.instanceOf(Object);
          expect(result).to.eql({});
        }
      ).then(done, done);
    })
  })
})
