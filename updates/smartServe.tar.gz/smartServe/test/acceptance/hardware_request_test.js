'use strict'
require('../helper')

var http = require('http'), server;
var hardware = require('../../const/hardware_object');

before(function(){
  server = http.createServer(require('../../app'));
  server.listen(0);
  browser.baseUrl = 'http://localhost:' + server.address().port;
});

beforeEach(function(){
  return browser.ignoreSynchronization = true;
})

after(function(){
  server.close();
})

describe('Given smartServe', function(){
  describe('When I browse to hardware request', function(){
    before(()=>{
      browser.get('/').then(()=>{
        browser.executeScript('localStorage.clear()');
      })
      browser.sleep(1000)
      browser.get('/').then(()=>{
        element(by.id('ntid')).sendKeys('sys-cf-smrt')
        element(by.id('getinfo')).click()
      })
      browser.sleep(1000)
    })
    it('then there should be a justification dropdown', function(){
      browser.get('/hardwarerequest').then(function(){
        element(by.id('justification')).isPresent().then(function(present){
          expect(present).to.be.true;
        })
      })
    })
    it('then the dropdown shop have 8 options is co=United States', function(){
      browser.executeScript('var info = JSON.parse(localStorage.info); info["co"] = "United States"; localStorage.setItem("info", JSON.stringify(info));')
      browser.sleep(1000);
      var expected = [
        '-- Select An Option --',
        'New employee',
        'Requesting on behalf of someone else',
        'Team support / on-call laptop',
        'Requesting lab machine',
        'Migrate to new device',
        'Replace broken and out of warranty equipment'
      ]
      browser.get('/hardwarerequest').then(function(){
        element.all(by.css('.justificationClass')).getText().then(function(text){
          expect(text).to.eql(expected)
        })
      })
    })
    it('then the dropdown shop have 8 options is co != United States', function(){
      browser.executeScript('var info = JSON.parse(localStorage.info); info["co"] = "UK"; localStorage.setItem("info", JSON.stringify(info));')
      browser.sleep(1000);
      var expected = [
        '-- Select An Option --',
        'New employee',
        'Requesting on behalf of someone else',
        'Team support / on-call laptop',
        'Requesting lab machine',
        'Migrate to new device'
      ]
      browser.get('/hardwarerequest').then(function(){
        element.all(by.css('.justificationClass')).getText().then(function(text){
          expect(text).to.eql(expected)
        })
      })
      browser.executeScript('var info = JSON.parse(localStorage.info); info["co"] = "UK"; localStorage.setItem("info", JSON.stringify(info));')
      browser.sleep(1000);
      browser.get('/hardwarerequest').then(function(){
        element.all(by.css('.justificationClass')).getText().then(function(text){
          expect(text).to.eql(expected)
        })
      })
    })
    it('then shoud have a cancel button which redirects back to the hardware request page', function(){
      browser.get('/hardwarerequest').then(function(){
        let cancel = element(by.css('.btn--dismiss'))
        cancel.isPresent().then(function(present){
          expect(present).to.be.true;
        })
        cancel.getAttribute('href').then(function(attr){
          expect(attr).to.equal(browser.baseUrl + '/')
        })
      })
    })

    it('should display hardware offered', function(){
      var expected = hardware.filter((item, index, array)=>{
        return item.type;
      }).map((item, index, array)=>{
        return item.type
      })
      browser.get('/hardwarerequest').then(function(){
        let items = element.all(by.css('.hardwareItem'))
        items.getAttribute('data-type').then(function(types){
          expect(types).to.eql(expected)
        })
      })
    })
    it('should display only laptops when oncall is selected for justification', function(){
      browser.get('/hardwarerequest').then(function(){
        var expected = hardware.filter((item, index, array)=>{
          if(item.type === 'Laptop'){
            return item.type
          }
        }).map((item, index, array)=>{
          return item.type
        })
        element.all(by.css(".justificationClass")).get(3).click().then(function (){
          let items = element.all(by.css('.hardwareItem'))
          items.getAttribute('data-type').then(function(types){
            expect(types).to.eql(expected)
          })
        })
      })
    })
    it('should display only lab machine when lab is selected for justification', function(){
      browser.get('/hardwarerequest').then(function(){
        var expected = hardware.filter((item, index, array)=>{
          if(item.type === 'Lab'){
            return item.type
          }
        }).map((item, index, array)=>{
          return item.type
        })
        element.all(by.css(".justificationClass")).get(4).click().then(function (){
          let items = element.all(by.css('.hardwareItem'))
          items.getAttribute('data-type').then(function(types){
            expect(types).to.eql(expected)
          })
        })
      })
    })
    it('should have a filter dropdown', function(){
      browser.get('/hardwarerequest').then(function(){
        element(by.id('hardwarefilter')).isPresent().then(function (present) {
          expect(present).to.eql(true)
        })
      })
    })
    it('should show all when all is selcted', function () {
      browser.get('/hardwarerequest').then(function() {
        var expected = hardware.filter((item, index, array)=>{
          return item.type
        }).map((item, index, array)=>{
          return item.type
        })
        element.all(by.css('.filterClass')).get(0).click().then(function(){
          let items = element.all(by.css('.hardwareItem'))
          items.getAttribute('data-type').then(function(types){
            expect(types).to.eql(expected)
          })
        })
      })
    })
    it('should show laptops when Laptop is selcted', function () {
      browser.get('/hardwarerequest').then(function() {
        var expected = hardware.filter((item, index, array)=>{
          if(item.type === 'Laptop'){
            return item.type
          }
        }).map((item, index, array)=>{
          return item.type
        })
        element.all(by.css('.filterClass')).get(1).click().then(function(){
          let items = element.all(by.css('.hardwareItem'))
          items.getAttribute('data-type').then(function(types){
            expect(types).to.eql(expected)
          })
        })
      })
    })
    it('should show desktops when desktop is selcted', function () {
      browser.get('/hardwarerequest').then(function() {
        var expected = hardware.filter((item, index, array)=>{
          if(item.type === 'Desktop'){
            return item.type
          }
        }).map((item, index, array)=>{
          return item.type
        })
        element.all(by.css('.filterClass')).get(2).click().then(function(){
          let items = element.all(by.css('.hardwareItem'))
          items.getAttribute('data-type').then(function(types){
            expect(types).to.eql(expected)
          })
        })
      })
    })
    it('should show apples when apple is selcted', function () {
      browser.get('/hardwarerequest').then(function() {
        var expected = hardware.filter((item, index, array)=>{
          if(item.type === 'Apple'){
            return item.type
          }
        }).map((item, index, array)=>{
          return item.type
        })
        element.all(by.css('.filterClass')).get(3).click().then(function(){
          let items = element.all(by.css('.hardwareItem'))
          items.getAttribute('data-type').then(function(types){
            expect(types).to.eql(expected)
          })
        })
      })
    })
    it('should show tablets when tablet is selcted', function () {
      browser.get('/hardwarerequest').then(function() {
        var expected = hardware.filter((item, index, array)=>{
          if(item.type === 'Tablet'){
            return item.type
          }
        }).map((item, index, array)=>{
          return item.type
        })
        element.all(by.css('.filterClass')).get(4).click().then(function(){
          let items = element.all(by.css('.hardwareItem'))
          items.getAttribute('data-type').then(function(types){
            expect(types).to.eql(expected)
          })
        })
      })
    })
    it('should show thin clients when thin client is selcted', function () {
      browser.get('/hardwarerequest').then(function() {
        var expected = hardware.filter((item, index, array)=>{
          if(item.type === 'Thin Client'){
            return item.type
          }
        }).map((item, index, array)=>{
          return item.type
        })
        element.all(by.css('.filterClass')).get(5).click().then(function(){
          let items = element.all(by.css('.hardwareItem'))
          items.getAttribute('data-type').then(function(types){
            expect(types).to.eql(expected)
          })
        })
      })
    })

    it('should show price for user with co=United States', function(){
      browser.executeScript('var info = JSON.parse(localStorage.info); info["co"] = "United States"; localStorage.setItem("info", JSON.stringify(info));')
      browser.sleep(1000);
      var expected = hardware.map((item, index, array)=>{
        return '$'+item.price
      })
      browser.get('/hardwarerequest').then(()=>{
        element.all(by.css('.hardware-price')).getText().then((prices)=>{
          expect(prices).to.eql(expected)
        })
      })
    })
    it('should not show price for co=UK', function(){
      browser.executeScript('var info = JSON.parse(localStorage.info); info["co"] = "UK"; localStorage.setItem("info", JSON.stringify(info));')
      browser.sleep(1000);
      browser.get('/hardwarerequest').then(()=>{
        element(by.css('.hardware-price')).isPresent().then((present)=>{
          expect(present).to.eql(false)
        })
      })
    })
    it('should not show price for co=UK', function(){
      browser.executeScript('var info = JSON.parse(localStorage.info); info["co"] = "India"; localStorage.setItem("info", JSON.stringify(info));')
      browser.sleep(1000);
      browser.get('/hardwarerequest').then(()=>{
        element(by.css('.hardware-price')).isPresent().then((present)=>{
          expect(present).to.eql(false)
        })
      })
    })

    it('should have quantity fields disabled before a justification has been selected', function(){
      browser.executeScript('var info = JSON.parse(localStorage.info); info["co"] = "UK"; localStorage.setItem("info", JSON.stringify(info));')
      var expected = hardware.map((item, index, array)=>{
        return 'true'
      })
      browser.get('/hardwarerequest').then(()=>{
        element.all(by.css('.hardware-quantity-field')).getAttribute('disabled').then((disabled)=>{
          expect(disabled).to.eql(expected);
        })
      })
    })
    it('should make quantity fields enabled after justification has been selected', function(){
      var expected = hardware.map((item, index, array)=>{
        return null;
      })
      browser.get('/hardwarerequest').then(()=>{
        element.all(by.css('.justificationClass')).get(1).click().then(()=>{
          element.all(by.css('.hardware-quantity-field')).getAttribute('disabled').then((disabled)=>{
            expect(disabled).to.eql(expected);
          })
        })
      })
    })

    it('should add highlight class when quantity is more than one', function(){
      browser.get('/hardwarerequest').then(()=>{
        element.all(by.css(".justificationClass")).get(1).click().then(()=>{
          element.all(by.css('.hardware-quantity-field')).get(0).sendKeys('1').then(()=>{
            element(by.css('.hardwareItemHighlight')).isPresent().then((present)=>{
              expect(present).to.eql(true)
            })
          })
        })
      })
    })

    it('should have a continue button at the bottom of the page', function(){
      browser.get('/hardwarerequest').then(()=>{
        element(by.id('continue_order')).isPresent().then((present)=>{
          expect(present).to.eql(true);
        })
      })
    })

    it('should redirect to /hardwarerequest/ordersummary if thin client is not selected', function(){
      browser.get('/hardwarerequest').then(()=>{
        element.all(by.css('.justificationClass')).get(1).click().then(()=>{
          element.all(by.css('.hardware-quantity-field')).get(0).sendKeys('1').then(()=>{
            element(by.id('continue_order')).click().then(()=>{
              browser.getCurrentUrl().then((url)=>{
                expect(url).to.eql(browser.baseUrl + "/hardwarerequest/ordersummary")
              })
            })
          })
        })
      })
    })

    it('should redirect to /hardwarerequest/svdcheck if thin client is selected and user does not have svd/dvd account', function(){
      browser.get('/hardwarerequest').then(()=>{
        element.all(by.css('.justificationClass')).get(1).click().then(()=>{
          element.all(by.css('.hardware-quantity-field')).get(8).sendKeys('1').then(()=>{
            element(by.id('continue_order')).click().then(()=>{
              browser.getCurrentUrl().then((url)=>{
                expect(url).to.eql(browser.baseUrl + "/hardwarerequest/svdcheck")
              })
            })
          })
        })
      })
    })

    it('should redirect to to /hardwarerequest/ordersummary if thin clinet is selected and user does have svd/dvd account', function(){
      browser.executeScript('var info = JSON.parse(localStorage.info); var memberOf = info["memberOf"]; memberOf.push("DVD"); info["memberOf"] = memberOf; localStorage.setItem("info", JSON.stringify(info));');
      browser.sleep(1000);
      browser.get('/hardwarerequest').then(()=>{
        element.all(by.css('.justificationClass')).get(1).click().then(()=>{
          element.all(by.css('.hardware-quantity-field')).get(8).sendKeys('1').then(()=>{
            element(by.id('continue_order')).click().then(()=>{
              browser.getCurrentUrl().then((url)=>{
                expect(url).to.eql(browser.baseUrl + "/hardwarerequest/ordersummary")
              })
            })
          })
        })
      })
    })
  })
})
