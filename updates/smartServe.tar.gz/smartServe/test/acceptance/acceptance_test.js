'use strict'
require('../helper')

var http = require('http'), server;

before(function(){
  server = http.createServer(require('../../app'));
  server.listen(0);
  browser.baseUrl = 'http://localhost:' + server.address().port;
});

beforeEach(function(){
  return browser.ignoreSynchronization = true;
})

after(function(){
  server.close();
})

describe('Given the smartServe application', function(){
  describe('When a page loads', function(){
    it('then it should have a navigation bar with an allstate logo', function(){
      browser.get('/').then(function(){
        element.all(by.tagName('img')).get(0).isPresent().then(function(present){
          expect(present).to.be.true;
        })
      })
    })
    it('then it should have links containing Home [**add more to this test if needed**]', function(){
      browser.get('/').then(function(){
        element.all(by.css('.masthead-links')).getText().then(function(text){
          expect(text).to.eql(['Home'])
        })
      })
    })
    it('then it should have a background of #004a88', function(){
      browser.get('/').then(function(){
        element(by.css('.masthead-logo')).getCssValue('background-color').then(function(value){
          // rgba(0, 74 ,136, 1) == #004a88 == @brand--alt--x4 (see style guide for allstate ui)
          expect(value).to.equal('rgba(0, 74, 136, 1)')
        })
      })
    })
  })

  describe('given a ntid', function(){
    it('should then authenticate the user and store user details in localstorage', function(){
      browser.get('/').then(function(){
        element(by.id('ntid')).sendKeys('sys-cf-smrt')
        element(by.id('getinfo')).click().then(function(){
          element(by.css('.masthead-user')).getText(function(text){
            expect(text).to.eql('Welcome Service Account')
          })
        })
      })
    })
  })
})
