'use strict'
var request = require('supertest');
var app = require('../../app');
require('../helper')

describe('GET /', function () {
  it('routes correctly', function (done) {
    request(app).get('/')
      .expect(200, done)
  });
});

describe('GET /users/:ntid/getinfo', function(){
  it('routes correctly', function(done) {
    request(app).get('/users/sys-cf-smrt/getinfo').expect(200, done);
  })
  it('return json object with user info', function(done){
    request(app).get('/users/sys-cf-smrt/getinfo').end(function(req, res){
      expect(res.body).to.be.instanceOf(Object);
      expect(res.body.givenName).to.eql('Service')
      expect(res.body.sn).to.eql('Account')
      done()
    })
  })
  it('returns 401 when invalid ntid is used', function(done){
    request(app).get('/users/incorrectntid/getinfo').expect(401, done);
  })
})
